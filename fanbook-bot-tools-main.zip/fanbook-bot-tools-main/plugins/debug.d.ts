declare interface Window {
  qd: () => void;
}
