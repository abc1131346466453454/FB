rm -rf .output dist;
nuxi generate;
